import 'bootstrap';
import './dashboard';

// Inizializzazione app
window.addEventListener('DOMContentLoaded', function() {
    console.log('Gestionale Croce Verde caricato');
});
